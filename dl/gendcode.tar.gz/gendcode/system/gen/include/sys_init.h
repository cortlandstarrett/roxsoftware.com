/*****************************************************************************
 * File:  sys_init.h
 *
 * Description:
 * Main entrance to the wild thing...
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef SYS_INIT_H
#define SYS_INIT_H

#ifdef	__cplusplus
extern "C" {
#endif


/*****************************************************************************
 * System Name: a.out
 * System ID:   1
 *
 * Model Compiler Product Information:
 * Product: MC3020
 * Version: V1.0.0
 * S/N:     302010099031407
 *
 * System default/colored values:
 * MaxStringLen: 32
 * MaxObjExtent: 0
 * MaxRelExtent: 0
 * MaxSelectExtent: 0
 * MaxSelfEvents: 0
 * MaxNonSelfEvents: 0
 * MaxTimers: 2
 ****************************************************************************/

#define SYS_MAX_STRING_LEN 32

#define SYS_MAX_OBJECT_EXTENT 5

#define SYS_MAX_RELATIONSHIP_EXTENT 0

#define SYS_MAX_TRANSIENT_EXTENT 4

#define SYS_MAX_CONTAINERS \
        ( SYS_MAX_OBJECT_EXTENT + SYS_MAX_RELATIONSHIP_EXTENT + SYS_MAX_TRANSIENT_EXTENT )

#define SYS_MAX_SELF_EVENTS 2

#define SYS_MAX_NON_SELF_EVENTS 4

#define SYS_MAX_OOA_EVENTS \
        ( SYS_MAX_SELF_EVENTS + SYS_MAX_NON_SELF_EVENTS )

/* Note: User adjusted from calculated estimate value: 4 */
#define SYS_MAX_OOA_TIMERS 2


/*****************************************************************************
 * Domain Name: A
 * Domain ID:   1
 * Repository:  as
 * OOA Version: 11
 *
 * MaxObjExtent: 5
 * MaxRelExtent: 0
 * MaxSelectExtent: 4
 * MaxSelfEvents: 2
 * MaxNonSelfEvents: 4
 * MaxTimers: 1
 ****************************************************************************/



/*****************************************************************************
 * OOA domain identification numbers 
 ****************************************************************************/
#define A_DOMAIN_ID  1

extern void SystemLevelInitialization( void );
extern void ApplicationLevelInitialization( void );
extern void SystemLevelShutdown( void );
extern void ApplicationLevelShutdown( void );

#ifdef	__cplusplus
}
#endif

#endif  /* SYS_INIT_H */
