/*****************************************************************************
 * File: init_seq.c
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/


#include "A_dom_init.h"

void RunApplicationInitSequence()
{
/***************************************************************************
 * Initialization Object:
 *
 * Domain:     A
 * Subsystem:  autosampler
 * Object:     autosampler init  (I)
 *
 * Repository: as.ooa
 *
 * State action sequencing follows:
 **************************************************************************/
  A_I_InitState_1();

}
