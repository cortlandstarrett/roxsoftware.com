/*****************************************************************************
 * File:       SPPIO_bridge.c
 *
 * Description:
 *
 * External Entity: 'PIO_2'  (SPPIO)
 ****************************************************************************/


#include "SPPIO_bridge.h"

/*****************************************************************************
 * Bridge: SPPIO_raise_needle
 ****************************************************************************/
char *
SPPIO_raise_needle(
    const int ee_probe_id,
    const int ee_radial_position,
    const int ee_theta_offset )
{
  char * result;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: SPPIO_lower_needle
 ****************************************************************************/
char *
SPPIO_lower_needle(
    const int ee_probe_id,
    const int ee_radial_position,
    const int ee_theta_offset )
{
  char * result;

  /* Insert your implementation code here... */
  
  return result;
}


