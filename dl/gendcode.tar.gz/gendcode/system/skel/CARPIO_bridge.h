/*****************************************************************************
 * File:       CARPIO_bridge.h
 *
 * Description:
 *
 * External Entity: 'PIO_1'  (CARPIO)
 ****************************************************************************/

#ifndef CARPIO_BRIDGE_H
#define CARPIO_BRIDGE_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"

/*****************************************************************************
 * Bridge: CARPIO_current_position
 ****************************************************************************/
extern int CARPIO_current_position(
    const int ee_car_id );

/*****************************************************************************
 * Bridge: CARPIO_carousel_spin
 ****************************************************************************/
extern void CARPIO_carousel_spin(
    const int ee_car_id,
    const int ee_destination );


#ifdef	__cplusplus
}
#endif

#endif  /* CARPIO_BRIDGE_H */

