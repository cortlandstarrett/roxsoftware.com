/*****************************************************************************
 * File:       A_SP_actions.c
 *
 * Description:
 * State actions methods implementation for the following object:
 *
 * Object:     sampling_probe  (SP)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "e_mechs.h"
#include "e_events.h"
#include "A_objects.h"
#include "A_enums.h"
#include "sys_init.h"
#include "A_ROW_object.h"
#include "A_ROW_events.h"
#include "A_SP_object.h"
#include "A_SP_events.h"
#include "A_PAA_object.h"
#include "A_PAA_ASG.h"
#include "A_PAA_ASG_events.h"
#include "TIM_bridge.h"
#include "SPPIO_bridge.h"

/*****************************************************************************
 * State [1]: 'up'
 ****************************************************************************/
void
A_SP_Action_1( A_SP_s * self, const OoaEvent_t * const event )
{
  A_ROW_s * v33;  /* row */

  /* ASSIGN SELF.current_position = 'up' */
  self->m_current_position = A_position_up_e;

  /* SELECT ONE row RELATED BY SELF->ROW[R2] */
  v33 = (A_ROW_s *)0;
  { /* Begin navigation scope */
    A_PAA_s * p31_PAA_R2 = self->mc_PAA_R2;
    if ( p31_PAA_R2 )
    {
      A_ROW_s * p32_ROW_R2 = p31_PAA_R2->mc_ROW_R2;
      v33 = p32_ROW_R2;  
    }
  } /* End navigation scope */

  /* GENERATE ROW4:'sample_complete'() TO row */
  {
    A_ROW_Event4_s * event34 = New_A_ROW_Event4_s( v33 );
    Escher_SendEvent( (OoaEvent_t *)event34 );
  }

}

/*****************************************************************************
 * State [2]: 'down'
 ****************************************************************************/
void
A_SP_Action_2( A_SP_s * self, const OoaEvent_t * const event )
{
  A_ROW_s * v38;  /* row */
  A_SP_Event1_s * v40;  /* move_on */
  Escher_Timer_t * v41;  /* mo_timer */
  int v39;  /* st */

  /* SELECT ONE row RELATED BY SELF->ROW[R2] */
  v38 = (A_ROW_s *)0;
  { /* Begin navigation scope */
    A_PAA_s * p36_PAA_R2 = self->mc_PAA_R2;
    if ( p36_PAA_R2 )
    {
      A_ROW_s * p37_ROW_R2 = p36_PAA_R2->mc_ROW_R2;
      v38 = p37_ROW_R2;  
    }
  } /* End navigation scope */

  /* ASSIGN st = row.sampling_time */
  v39 = v38->m_sampling_time;

  /* CREATE EVENT INSTANCE move_on SP1:'finished_sampling'() TO SELF */
  v40 = New_A_SP_Event1_s( self );

  /* ASSIGN mo_timer = TIM::timer_start(microseconds:st, event_inst:move_on) */
  v41 = TIM_timer_start( (OoaEvent_t *)v40, v39 );

}

/*****************************************************************************
 * State [3]: 'raising'
 ****************************************************************************/
void
A_SP_Action_3( A_SP_s * self, const OoaEvent_t * const event )
{
  char v42[ SYS_MAX_STRING_LEN ];  /* needle_position */

  v42[ 0 ] = '\0';

  /* ASSIGN needle_position = SPPIO::raise_needle(radial_position:SELF.radial_position, theta_offset:SELF.theta_offset, probe_id:SELF.probe_ID) */
  strncpy( v42, SPPIO_raise_needle( self->m_probe_ID, self->m_radial_position, self->m_theta_offset ), SYS_MAX_STRING_LEN );

}

/*****************************************************************************
 * State [4]: 'lowering'
 ****************************************************************************/
void
A_SP_Action_4( A_SP_s * self, const OoaEvent_t * const event )
{
  A_PAA_s * v44;  /* assignment */
  char v46[ SYS_MAX_STRING_LEN ];  /* needle_position */

  v46[ 0 ] = '\0';

  /* SELECT ANY assignment FROM INSTANCES OF PAA
     WHERE (SELECTED.probe_ID == SELF.probe_ID) */
  v44 = (A_PAA_s *)0;
  { /* Begin selection scope */
    A_PAA_s * w43;
    Escher_Iterator_s iter45_PAA;
    Escher_IteratorReset( &iter45_PAA, pG_A_PAA_extent );
    while ( (w43 = (A_PAA_s *)Escher_IteratorNext( &iter45_PAA )) != 0 )
    {
      if ( (w43->m_probe_ID == self->m_probe_ID) )
      {
        v44 = w43;
        break;
      }
    }
  } /* End selection scope */

  /* ASSIGN needle_position = SPPIO::lower_needle(radial_position:SELF.radial_position, theta_offset:SELF.theta_offset, probe_id:SELF.probe_ID) */
  strncpy( v46, SPPIO_lower_needle( self->m_probe_ID, self->m_radial_position, self->m_theta_offset ), SYS_MAX_STRING_LEN );

  /* ASSIGN SELF.current_position = 'down' */
  self->m_current_position = A_position_down_e;

}

