/*****************************************************************************
 * File:       A_ROW_actions.c
 *
 * Description:
 * State actions methods implementation for the following object:
 *
 * Object:     row  (ROW)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "e_mechs.h"
#include "e_events.h"
#include "A_objects.h"
#include "A_CAR_object.h"
#include "A_CAR_events.h"
#include "A_ROW_object.h"
#include "A_ROW_events.h"
#include "A_SP_object.h"
#include "A_SP_events.h"
#include "A_PAA_object.h"
#include "A_PAA_ASG.h"
#include "A_PAA_ASG_events.h"
#include "A_ROW_xform.h"


/*****************************************************************************
 * State [1]: 'idle'
 ****************************************************************************/
void
A_ROW_Action_1( A_ROW_s * self, const OoaEvent_t * const event )
{
  A_PAA_s * v13;  /* assignment */
  A_SP_s * v16;  /* probe */

  /* ASSIGN SELF.current_sampling_position = 0 */
  self->m_current_sampling_position = 0;

  /* SELECT ONE assignment RELATED BY SELF->PAA[R2] */
  v13 = self->mc_PAA_R2;

  /* SELECT ONE probe RELATED BY assignment->SP[R2] */
  v16 = v13->mc_SP_R2;

  /* UNRELATE SELF FROM probe ACROSS R2 USING assignment */
  A_PAA_R2_Unlink( self, v16, v13 );

  /* DELETE OBJECT INSTANCE assignment */
  A_PAA_Delete( v13 );

}

/*****************************************************************************
 * State [2]: 'waiting'
 ****************************************************************************/
void
A_ROW_Action_2( A_ROW_s * self, const OoaEvent_t * const event )
{

  /* ASSIGN SELF.needs_probe = TRUE */
  self->m_needs_probe = true;

  /* GENERATE PAA_A1:'row_needs_probe'() TO PAA ASSIGNER */
  {
    A_PAA_AsgEvent1_s * event17 = New_A_PAA_AsgEvent1_s();
    Escher_SendEvent( (OoaEvent_t *)event17 );
  }

}

/*****************************************************************************
 * State [3]: 'positioning'
 ****************************************************************************/
void
A_ROW_Action_3( A_ROW_s * self, const OoaEvent_t * const event )
{
  A_CAR_s * v20;  /* car */
  int v21;  /* next */

  /* SELECT ONE car RELATED BY SELF->CAR[R1] */
  v20 = self->mc_CAR_R1;

  /* ASSIGN SELF.next_sampling_position = SELF.current_sampling_position + 1 */
  self->m_next_sampling_position = self->m_current_sampling_position + 1;

  /* ASSIGN next = ROW::convert_dest(radius:SELF.radius, next_sampling_position:SELF.next_sampling_position) */
  v21 = A_ROW_Xform_convert_dest( self->m_next_sampling_position, self->m_radius );

  /* GENERATE CAR1:'go'(destination:next) TO car */
  {
    A_CAR_Event1_s * event22 = New_A_CAR_Event1_s( v20 );
    event22->m_destination = v21;
    Escher_SendEvent( (OoaEvent_t *)event22 );
  }

}

/*****************************************************************************
 * State [4]: 'sampling'
 ****************************************************************************/
void
A_ROW_Action_4( A_ROW_s * self, const OoaEvent_t * const event )
{
  A_SP_s * v26;  /* probe */

  /* SELECT ONE probe RELATED BY SELF->PAA[R2]->SP[R2] */
  v26 = (A_SP_s *)0;
  { /* Begin navigation scope */
    A_PAA_s * p24_PAA_R2 = self->mc_PAA_R2;
    if ( p24_PAA_R2 )
    {
      A_SP_s * p25_SP_R2 = p24_PAA_R2->mc_SP_R2;
      v26 = p25_SP_R2;  
    }
  } /* End navigation scope */

  /* ASSIGN SELF.current_sampling_position = SELF.current_sampling_position + 1 */
  self->m_current_sampling_position = self->m_current_sampling_position + 1;

  /* GENERATE SP2:'begin_sampling'() TO probe */
  {
    A_SP_Event2_s * event27 = New_A_SP_Event2_s( v26 );
    Escher_SendEvent( (OoaEvent_t *)event27 );
  }

}

/*****************************************************************************
 * State [5]: 'checking'
 ****************************************************************************/
void
A_ROW_Action_5( A_ROW_s * self, const OoaEvent_t * const event )
{

  /* IF (SELF.next_sampling_position < SELF.maximum_sampling_positions) */
  if ( (self->m_next_sampling_position < self->m_maximum_sampling_positions) )
  {
    /* GENERATE ROW5:'next_sample'() TO SELF */
    {
      A_ROW_Event5_s * event28 = New_A_ROW_Event5_s( self );
      Escher_SendSelfEvent( (OoaEvent_t *)event28 );
    }
  }
  /* ELSE */
  else
  {
    /* GENERATE ROW6:'sampling_complete'() TO SELF */
    {
      A_ROW_Event6_s * event29 = New_A_ROW_Event6_s( self );
      Escher_SendSelfEvent( (OoaEvent_t *)event29 );
    }
  }
  /* END IF */

}

