/*****************************************************************************
 * File:       A_ROW_events.c
 *
 * Description:
 * Event classes for the following object:
 *
 * Object:     row  (ROW)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "A_objects.h"
#include "A_ROW_object.h"
#include "A_ROW_events.h"

/*****************************************************************************
 * New_A_ROW_Event1_s
 ****************************************************************************/
A_ROW_Event1_s *
New_A_ROW_Event1_s( const A_ROW_s * const dest )
{
  A_ROW_Event1_s * event = (A_ROW_Event1_s *) Escher_AllocateOoaEvent( sizeof( A_ROW_Event1_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_ROW_OBJECT_ID );
  SetOoaEventNumber( event, A_ROW_EVENT_ROW1 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}

/*****************************************************************************
 * New_A_ROW_Event2_s
 ****************************************************************************/
A_ROW_Event2_s *
New_A_ROW_Event2_s( const A_ROW_s * const dest )
{
  A_ROW_Event2_s * event = (A_ROW_Event2_s *) Escher_AllocateOoaEvent( sizeof( A_ROW_Event2_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_ROW_OBJECT_ID );
  SetOoaEventNumber( event, A_ROW_EVENT_ROW2 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}

/*****************************************************************************
 * New_A_ROW_Event3_s
 ****************************************************************************/
A_ROW_Event3_s *
New_A_ROW_Event3_s( const A_ROW_s * const dest )
{
  A_ROW_Event3_s * event = (A_ROW_Event3_s *) Escher_AllocateOoaEvent( sizeof( A_ROW_Event3_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_ROW_OBJECT_ID );
  SetOoaEventNumber( event, A_ROW_EVENT_ROW3 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}

/*****************************************************************************
 * New_A_ROW_Event4_s
 ****************************************************************************/
A_ROW_Event4_s *
New_A_ROW_Event4_s( const A_ROW_s * const dest )
{
  A_ROW_Event4_s * event = (A_ROW_Event4_s *) Escher_AllocateOoaEvent( sizeof( A_ROW_Event4_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_ROW_OBJECT_ID );
  SetOoaEventNumber( event, A_ROW_EVENT_ROW4 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}

/*****************************************************************************
 * New_A_ROW_Event5_s
 ****************************************************************************/
A_ROW_Event5_s *
New_A_ROW_Event5_s( const A_ROW_s * const dest )
{
  A_ROW_Event5_s * event = (A_ROW_Event5_s *) Escher_AllocateOoaEvent( sizeof( A_ROW_Event5_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_ROW_OBJECT_ID );
  SetOoaEventNumber( event, A_ROW_EVENT_ROW5 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}

/*****************************************************************************
 * New_A_ROW_Event6_s
 ****************************************************************************/
A_ROW_Event6_s *
New_A_ROW_Event6_s( const A_ROW_s * const dest )
{
  A_ROW_Event6_s * event = (A_ROW_Event6_s *) Escher_AllocateOoaEvent( sizeof( A_ROW_Event6_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_ROW_OBJECT_ID );
  SetOoaEventNumber( event, A_ROW_EVENT_ROW6 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}


