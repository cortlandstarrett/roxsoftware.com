/*****************************************************************************
 * File:       A_PAA_ASG_actions.c
 *
 * Description:
 * State actions methods implementation for the following object Assigner:
 *
 * Object:     probe_assignment  (PAA)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "e_mechs.h"
#include "e_events.h"
#include "A_objects.h"
#include "A_ROW_object.h"
#include "A_ROW_events.h"
#include "A_SP_object.h"
#include "A_SP_events.h"
#include "A_PAA_object.h"
#include "A_PAA_ASG.h"
#include "A_PAA_ASG_events.h"

/*****************************************************************************
 * State [1]: 'waiting on row'
 ****************************************************************************/
void
A_PAA_ASG_Action_1( A_PAA_Asg_s * self, const OoaEvent_t * const event )
{
  A_ROW_s * v48;  /* row */

  /* SELECT ANY row FROM INSTANCES OF ROW
     WHERE (SELECTED.needs_probe == TRUE) */
  v48 = (A_ROW_s *)0;
  { /* Begin selection scope */
    A_ROW_s * w47;
    Escher_Iterator_s iter49_ROW;
    Escher_IteratorReset( &iter49_ROW, pG_A_ROW_extent );
    while ( (w47 = (A_ROW_s *)Escher_IteratorNext( &iter49_ROW )) != 0 )
    {
      if ( (w47->m_needs_probe == true) )
      {
        v48 = w47;
        break;
      }
    }
  } /* End selection scope */

  /* IF (NOT_EMPTY row) */
  if ( (((v48 != 0) ? true : false)) )
  {
    /* GENERATE PAA_A1:'row_needs_probe'() TO PAA ASSIGNER */
    {
      A_PAA_AsgEvent1_s * event50 = New_A_PAA_AsgEvent1_s();
      Escher_SendSelfEvent( (OoaEvent_t *)event50 );
    }
  }
  /* END IF */

}

/*****************************************************************************
 * State [2]: 'waiting on probe'
 ****************************************************************************/
void
A_PAA_ASG_Action_2( A_PAA_Asg_s * self, const OoaEvent_t * const event )
{
  A_SP_s * v52;  /* probe */

  /* SELECT ANY probe FROM INSTANCES OF SP
     WHERE (SELECTED.available == TRUE) */
  v52 = (A_SP_s *)0;
  { /* Begin selection scope */
    A_SP_s * w51;
    Escher_Iterator_s iter53_SP;
    Escher_IteratorReset( &iter53_SP, pG_A_SP_extent );
    while ( (w51 = (A_SP_s *)Escher_IteratorNext( &iter53_SP )) != 0 )
    {
      if ( (w51->m_available == true) )
      {
        v52 = w51;
        break;
      }
    }
  } /* End selection scope */

  /* IF (NOT_EMPTY probe) */
  if ( (((v52 != 0) ? true : false)) )
  {
    /* GENERATE PAA_A2:'probe_available'() TO PAA ASSIGNER */
    {
      A_PAA_AsgEvent2_s * event54 = New_A_PAA_AsgEvent2_s();
      Escher_SendSelfEvent( (OoaEvent_t *)event54 );
    }
  }
  /* END IF */

}

/*****************************************************************************
 * State [3]: 'assigning pair'
 ****************************************************************************/
void
A_PAA_ASG_Action_3( A_PAA_Asg_s * self, const OoaEvent_t * const event )
{
  A_ROW_s * v56;  /* row */
  A_SP_s * v59;  /* probe */
  A_PAA_s * v61;  /* assignment */

  /* SELECT ANY row FROM INSTANCES OF ROW
     WHERE (SELECTED.needs_probe == TRUE) */
  v56 = (A_ROW_s *)0;
  { /* Begin selection scope */
    A_ROW_s * w55;
    Escher_Iterator_s iter57_ROW;
    Escher_IteratorReset( &iter57_ROW, pG_A_ROW_extent );
    while ( (w55 = (A_ROW_s *)Escher_IteratorNext( &iter57_ROW )) != 0 )
    {
      if ( (w55->m_needs_probe == true) )
      {
        v56 = w55;
        break;
      }
    }
  } /* End selection scope */

  /* SELECT ANY probe FROM INSTANCES OF SP
     WHERE (SELECTED.available == TRUE) */
  v59 = (A_SP_s *)0;
  { /* Begin selection scope */
    A_SP_s * w58;
    Escher_Iterator_s iter60_SP;
    Escher_IteratorReset( &iter60_SP, pG_A_SP_extent );
    while ( (w58 = (A_SP_s *)Escher_IteratorNext( &iter60_SP )) != 0 )
    {
      if ( (w58->m_available == true) )
      {
        v59 = w58;
        break;
      }
    }
  } /* End selection scope */

  /* ASSIGN probe.available = FALSE */
  v59->m_available = false;

  /* ASSIGN row.needs_probe = FALSE */
  v56->m_needs_probe = false;

  /* CREATE OBJECT INSTANCE assignment OF PAA */
  v61 = A_PAA_Create();

  /* RELATE row TO probe ACROSS R2 USING assignment */
  A_PAA_R2_Link( v56, v59, v61 );

  /* GENERATE PAA_A3:'probe_assigned'() TO PAA ASSIGNER */
  {
    A_PAA_AsgEvent3_s * event62 = New_A_PAA_AsgEvent3_s();
    Escher_SendSelfEvent( (OoaEvent_t *)event62 );
  }

  /* GENERATE ROW2:'probe_assigned'() TO row */
  {
    A_ROW_Event2_s * event63 = New_A_ROW_Event2_s( v56 );
    Escher_SendEvent( (OoaEvent_t *)event63 );
  }

}

