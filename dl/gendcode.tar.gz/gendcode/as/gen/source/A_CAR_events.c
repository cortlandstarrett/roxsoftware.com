/*****************************************************************************
 * File:       A_CAR_events.c
 *
 * Description:
 * Event classes for the following object:
 *
 * Object:     carousel  (CAR)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "A_objects.h"
#include "A_CAR_object.h"
#include "A_CAR_events.h"

/*****************************************************************************
 * New_A_CAR_Event1_s
 ****************************************************************************/
A_CAR_Event1_s *
New_A_CAR_Event1_s( const A_CAR_s * const dest )
{
  A_CAR_Event1_s * event = (A_CAR_Event1_s *) Escher_AllocateOoaEvent( sizeof( A_CAR_Event1_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_CAR_OBJECT_ID );
  SetOoaEventNumber( event, A_CAR_EVENT_CAR1 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}

/*****************************************************************************
 * New_A_CAR_Event2_s
 ****************************************************************************/
A_CAR_Event2_s *
New_A_CAR_Event2_s( const A_CAR_s * const dest )
{
  A_CAR_Event2_s * event = (A_CAR_Event2_s *) Escher_AllocateOoaEvent( sizeof( A_CAR_Event2_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_CAR_OBJECT_ID );
  SetOoaEventNumber( event, A_CAR_EVENT_CAR2 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}


