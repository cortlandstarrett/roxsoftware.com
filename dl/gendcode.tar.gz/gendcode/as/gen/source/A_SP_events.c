/*****************************************************************************
 * File:       A_SP_events.c
 *
 * Description:
 * Event classes for the following object:
 *
 * Object:     sampling_probe  (SP)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "A_objects.h"
#include "A_SP_object.h"
#include "A_SP_events.h"

/*****************************************************************************
 * New_A_SP_Event1_s
 ****************************************************************************/
A_SP_Event1_s *
New_A_SP_Event1_s( const A_SP_s * const dest )
{
  A_SP_Event1_s * event = (A_SP_Event1_s *) Escher_AllocateOoaEvent( sizeof( A_SP_Event1_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_SP_OBJECT_ID );
  SetOoaEventNumber( event, A_SP_EVENT_SP1 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}

/*****************************************************************************
 * New_A_SP_Event2_s
 ****************************************************************************/
A_SP_Event2_s *
New_A_SP_Event2_s( const A_SP_s * const dest )
{
  A_SP_Event2_s * event = (A_SP_Event2_s *) Escher_AllocateOoaEvent( sizeof( A_SP_Event2_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_SP_OBJECT_ID );
  SetOoaEventNumber( event, A_SP_EVENT_SP2 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}

/*****************************************************************************
 * New_A_SP_Event3_s
 ****************************************************************************/
A_SP_Event3_s *
New_A_SP_Event3_s( const A_SP_s * const dest )
{
  A_SP_Event3_s * event = (A_SP_Event3_s *) Escher_AllocateOoaEvent( sizeof( A_SP_Event3_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_SP_OBJECT_ID );
  SetOoaEventNumber( event, A_SP_EVENT_SP3 );
  ClearOoaEventFlags( event );
  SetIsInstanceEvent( event );
  SetEventTargetInstance( event, dest );

  return event;
}


