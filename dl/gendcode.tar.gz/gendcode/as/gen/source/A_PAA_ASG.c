/*****************************************************************************
 * File:  A_PAA_ASG.c
 *
 * Object:     probe_assignment  (PAA)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "A_PAA_ASG.h"

/*****************************************************************************
 * State-Event Matrix (SEM)
 * Row Index is object's current (MC enumerated) current state.
 * Row zero is the unitialized state (e.g., for creation event transitions).
 * Column Index is (MC enumerated) state machine events.
 *****************************************************************************/
static const Escher_StateNumber_t
A_PAA_AssignerStateEventMatrix[4][4] =
{
  /* Row 0: 'Unitialized' */
  { EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN },
  /* Row 1: A_PAA_ASG_STATE_1 'waiting on row' */
  { A_PAA_ASG_STATE_2, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED },
  /* Row 2: A_PAA_ASG_STATE_2 'waiting on probe' */
  { EVENT_IS_IGNORED, A_PAA_ASG_STATE_3, EVENT_IS_IGNORED, EVENT_IS_IGNORED },
  /* Row 3: A_PAA_ASG_STATE_3 'assigning pair' */
  { EVENT_IS_IGNORED, EVENT_IS_IGNORED, A_PAA_ASG_STATE_1, EVENT_IS_IGNORED }
};

/*****************************************************************************
 * Array of pointers to the object's state action methods.
 * Index is the (MC enumerated) number of the state action method to execute.
 ****************************************************************************/
static const StateAction_t
A_PAA_ASG_Actions[4] =
{
  (StateAction_t) 0,
  (StateAction_t) A_PAA_ASG_Action_1,  /* 'waiting on row' */
  (StateAction_t) A_PAA_ASG_Action_2,  /* 'waiting on probe' */
  (StateAction_t) A_PAA_ASG_Action_3   /* 'assigning pair' */
};

/*****************************************************************************
 * A_PAA_ASG_Dispatch - Assigner State model level event dispatching.
 ****************************************************************************/
static A_PAA_Asg_s self;

void
A_PAA_ASG_Dispatch( OoaEvent_t * event )
{
  Escher_EventNumber_t event_number;
  Escher_StateNumber_t current_state;
  Escher_StateNumber_t next_state;

  event_number = GetOoaEventNumber( event );
  current_state = self.mc_current_state;
  next_state = A_PAA_AssignerStateEventMatrix[ current_state ][ event_number ];

  if ( next_state <= 3 )
  {
    /* Execute the state action and update 'current state' */
    ( *A_PAA_ASG_Actions[ next_state ] )( &self, event );
    self.mc_current_state = next_state;
  }
  else
  {
    if ( next_state == EVENT_CANT_HAPPEN )
    {
      /* Event can't happen */
    }
    else if ( next_state == EVENT_IS_IGNORED )
    {
      /* Event ignored */
    }
    else
    {
      /* Translation/memory/stack error, etc - TBD */
    }
  }
}

/*****************************************************************************
 *
 ****************************************************************************/
void A_PAA_AssignerInit()
{
  self.mc_current_state = A_PAA_ASG_STATE_1;
}

/*****************************************************************************
 *
 ****************************************************************************/
void A_PAA_AssignerFini()
{
}

