/*****************************************************************************
 * File:  A_ROW_xform.h
 *
 * Description:
 * Transformers declared against the following application analysis object:
 *
 * Object:     row  (ROW)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_ROW_XFORM_H
#define A_ROW_XFORM_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"

/*****************************************************************************
 * Transformer: convert_dest
 ****************************************************************************/
extern int A_ROW_Xform_convert_dest(
    const int x_next_sampling_position,
    const int x_radius );

#ifdef	__cplusplus
}
#endif

#endif  /* A_ROW_XFORM_H */

