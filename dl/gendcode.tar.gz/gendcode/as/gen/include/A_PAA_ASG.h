/*****************************************************************************
 * File:  A_PAA_ASG.h
 *
 * Object:     probe_assignment  (PAA)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_PAA_ASG_H
#define A_PAA_ASG_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"
#include "e_events.h"
#include "A_objects.h"
    
/*****************************************************************************
 * Structure: A_PAA_Asg_s
 * Structural representation of application object assigner:
 *   'probe_assignment'  (PAA)
 ****************************************************************************/
struct A_PAA_Asg_s
{
  Escher_StateNumber_t mc_current_state;
};

extern void A_PAA_AssignerInit( void );
extern void A_PAA_AssignerFini( void );

/*****************************************************************************
 * State Action Methods
 *****************************************************************************/
extern void A_PAA_ASG_Action_1( A_PAA_Asg_s *, const OoaEvent_t * const );
extern void A_PAA_ASG_Action_2( A_PAA_Asg_s *, const OoaEvent_t * const );
extern void A_PAA_ASG_Action_3( A_PAA_Asg_s *, const OoaEvent_t * const );

extern void A_PAA_ASG_Dispatch( OoaEvent_t * );

/*****************************************************************************
 * Enumeration of state model states for object
 *****************************************************************************/
#define A_PAA_ASG_STATE_1 1  /* State [1]: 'waiting on row' */
#define A_PAA_ASG_STATE_2 2  /* State [2]: 'waiting on probe' */
#define A_PAA_ASG_STATE_3 3  /* State [3]: 'assigning pair' */

/*****************************************************************************
 * Enumeration of state model event numbers
 *****************************************************************************/
#define A_PAA_ASG_EVENT_PAA_A1 0  /* 'row_needs_probe' */
#define A_PAA_ASG_EVENT_PAA_A2 1  /* 'probe_available' */
#define A_PAA_ASG_EVENT_PAA_A3 2  /* 'probe_assigned' */
#define A_PAA_ASG_EVENT_PAA_A4 3  /* 'carousel_complete' */


#ifdef	__cplusplus
}
#endif

#endif  /* A_PAA_ASG_H */
