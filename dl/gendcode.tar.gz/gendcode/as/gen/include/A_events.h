/*****************************************************************************
 * File:       A_events.h
 *
 * Description:
 * Union of all events in the following domain:
 *
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_EVENTS_H
#define A_EVENTS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "A_CAR_events.h"
#include "A_ROW_events.h"
#include "A_SP_events.h"
#include "A_PAA_ASG_events.h"
    
/*****************************************************************************
 * Structure: A_DomainEvents_u
 ****************************************************************************/
union A_DomainEvents_u
{
  A_CAR_Events_u  namespace_dummy1;
  A_ROW_Events_u  namespace_dummy2;
  A_SP_Events_u  namespace_dummy3;
  A_PAA_ASG_Events_u  namespace_dummy4;
};
typedef union A_DomainEvents_u A_DomainEvents_u;
    
#ifdef	__cplusplus
}
#endif
#endif  /* A_EVENTS_H */

