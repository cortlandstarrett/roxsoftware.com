/*****************************************************************************
 * File:  A_ROW_object.h
 *
 * Object:     row  (ROW)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_ROW_OBJECT_H
#define A_ROW_OBJECT_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"
#include "e_events.h"
#include "A_objects.h"

/*****************************************************************************
 * Structure: A_ROW_s
 * Structural representation of application analysis object:
 *   'row'  (ROW)
 ****************************************************************************/
struct A_ROW_s
{
  /* Application analysis OIM attributes */
  int m_radius;  /* * radius */
  unsigned char m_current_sampling_position;  /* - current_sampling_position */
  unsigned char m_next_sampling_position;  /* - next_sampling_position */
  unsigned char m_maximum_sampling_positions;  /* - maximum_sampling_positions */
  /* - carousel_ID (R1) */  /* OPTIMIZED OUT */
  int m_sampling_time;  /* - sampling_time */
  bool m_needs_probe;  /* - needs_probe */

  /* Relationship storage */
  A_CAR_s * mc_CAR_R1;
  A_PAA_s * mc_PAA_R2;

  /* State machine current state */
  Escher_StateNumber_t mc_current_state;
};

/*****************************************************************************
 * Object Factory/Manipulation Methods
 ****************************************************************************/
extern void A_ROW_FactoryInit( void );
extern A_ROW_s * A_ROW_Create( void );
/* Note: No instance deletion accessor needed */

#define A_ROW_MAX_EXTENT_SIZE 1
extern Escher_ObjectSet_s * pG_A_ROW_extent;

/*****************************************************************************
 * Object Relationship Methods
 ****************************************************************************/

extern void A_ROW_R1_Link( A_CAR_s *, A_ROW_s * );
/* Note: No CAR<-R1->ROW unrelate accessor needed */

/*****************************************************************************
 * Enumeration of state model states for object
 *****************************************************************************/
#define A_ROW_STATE_1 1  /* State [1]: 'idle' */
#define A_ROW_STATE_2 2  /* State [2]: 'waiting' */
#define A_ROW_STATE_3 3  /* State [3]: 'positioning' */
#define A_ROW_STATE_4 4  /* State [4]: 'sampling' */
#define A_ROW_STATE_5 5  /* State [5]: 'checking' */

/*****************************************************************************
 * Enumeration of state model event numbers
 *****************************************************************************/
#define A_ROW_EVENT_ROW1 0  /* 'probe_request' */
#define A_ROW_EVENT_ROW2 1  /* 'probe_assigned' */
#define A_ROW_EVENT_ROW3 2  /* 'carousel_move_complete' */
#define A_ROW_EVENT_ROW4 3  /* 'sample_complete' */
#define A_ROW_EVENT_ROW5 4  /* 'next_sample' */
#define A_ROW_EVENT_ROW6 5  /* 'sampling_complete' */


/*****************************************************************************
 * State Action Methods
 ****************************************************************************/
extern void A_ROW_Action_1( A_ROW_s *, const OoaEvent_t * const );
extern void A_ROW_Action_2( A_ROW_s *, const OoaEvent_t * const );
extern void A_ROW_Action_3( A_ROW_s *, const OoaEvent_t * const );
extern void A_ROW_Action_4( A_ROW_s *, const OoaEvent_t * const );
extern void A_ROW_Action_5( A_ROW_s *, const OoaEvent_t * const );

extern void A_ROW_Dispatch( const OoaEvent_t * const );

#ifdef	__cplusplus
}
#endif

#endif  /* A_ROW_OBJECT_H */


