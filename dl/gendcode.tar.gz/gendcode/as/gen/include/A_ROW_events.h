/*****************************************************************************
 * File:       A_ROW_events.h
 *
 * Description:
 * Event classes for the following object:
 *
 * Object:     row  (ROW)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_ROW_EVENTS_H
#define A_ROW_EVENTS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "sys_init.h"
#include "e_mechs.h"
#include "e_events.h"

/* Forward reference */
#include "A_objects.h"

/*****************************************************************************
 * Structure: A_ROW_Event1_s
 * Instance Directed Event: ROW1:'probe_request'
 ****************************************************************************/
struct A_ROW_Event1_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_ROW_Event1_s A_ROW_Event1_s;
extern A_ROW_Event1_s * New_A_ROW_Event1_s( const A_ROW_s * const );

/*****************************************************************************
 * Structure: A_ROW_Event2_s
 * Instance Directed Event: ROW2:'probe_assigned'
 ****************************************************************************/
struct A_ROW_Event2_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_ROW_Event2_s A_ROW_Event2_s;
extern A_ROW_Event2_s * New_A_ROW_Event2_s( const A_ROW_s * const );

/*****************************************************************************
 * Structure: A_ROW_Event3_s
 * Instance Directed Event: ROW3:'carousel_move_complete'
 ****************************************************************************/
struct A_ROW_Event3_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_ROW_Event3_s A_ROW_Event3_s;
extern A_ROW_Event3_s * New_A_ROW_Event3_s( const A_ROW_s * const );

/*****************************************************************************
 * Structure: A_ROW_Event4_s
 * Instance Directed Event: ROW4:'sample_complete'
 ****************************************************************************/
struct A_ROW_Event4_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_ROW_Event4_s A_ROW_Event4_s;
extern A_ROW_Event4_s * New_A_ROW_Event4_s( const A_ROW_s * const );

/*****************************************************************************
 * Structure: A_ROW_Event5_s
 * Instance Directed Event: ROW5:'next_sample'
 ****************************************************************************/
struct A_ROW_Event5_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_ROW_Event5_s A_ROW_Event5_s;
extern A_ROW_Event5_s * New_A_ROW_Event5_s( const A_ROW_s * const );

/*****************************************************************************
 * Structure: A_ROW_Event6_s
 * Instance Directed Event: ROW6:'sampling_complete'
 ****************************************************************************/
struct A_ROW_Event6_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_ROW_Event6_s A_ROW_Event6_s;
extern A_ROW_Event6_s * New_A_ROW_Event6_s( const A_ROW_s * const );

/*****************************************************************************
 * A_ROW_Events_u
 * Union of events consumable by object's state machine.
 ****************************************************************************/
union A_ROW_Events_u
{
  A_ROW_Event1_s row1;
  A_ROW_Event2_s row2;
  A_ROW_Event3_s row3;
  A_ROW_Event4_s row4;
  A_ROW_Event5_s row5;
  A_ROW_Event6_s row6;
};
typedef union A_ROW_Events_u A_ROW_Events_u;

#ifdef	__cplusplus
}
#endif
#endif  /* A_ROW_EVENTS_H */

