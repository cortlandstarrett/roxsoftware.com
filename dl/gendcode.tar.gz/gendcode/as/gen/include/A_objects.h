/*****************************************************************************
 * File:  A_objects.h
 *
 * This file defines the object type identification numbers for all objects
 * in the following domain:
 *
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_OBJECTS_H
#define A_OBJECTS_H

#ifdef	__cplusplus
extern "C" {
#endif


/* Active Object: carousel  (CAR) [1] */
#define A_CAR_OBJECT_ID  1
typedef struct A_CAR_s A_CAR_s;

/* Active Object: row  (ROW) [2] */
#define A_ROW_OBJECT_ID  2
typedef struct A_ROW_s A_ROW_s;

/* Active Object: sampling_probe  (SP) [3] */
#define A_SP_OBJECT_ID  3
typedef struct A_SP_s A_SP_s;

/* Object Assigner: probe_assignment  (PAA) [4] */
#define A_PAA_ASSIGNER_ID  4
typedef struct A_PAA_Asg_s A_PAA_Asg_s;

/* Bridge Object: FBO_UI  (F) [6] */
#define A_F_OBJECT_ID  5

/* Init Object: autosampler init  (I) [5] */
#define A_I_OBJECT_ID  6

/* Passive Object: probe_assignment  (PAA) [4] */
#define A_PAA_OBJECT_ID  7
typedef struct A_PAA_s A_PAA_s;

#define A_STATE_MODELS  4

#ifdef	__cplusplus
}
#endif

#endif  /* A_OBJECTS_H */

