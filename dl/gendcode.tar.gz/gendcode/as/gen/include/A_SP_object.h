/*****************************************************************************
 * File:  A_SP_object.h
 *
 * Object:     sampling_probe  (SP)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_SP_OBJECT_H
#define A_SP_OBJECT_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"
#include "e_events.h"
#include "A_enums.h"
#include "A_objects.h"

/*****************************************************************************
 * Structure: A_SP_s
 * Structural representation of application analysis object:
 *   'sampling_probe'  (SP)
 ****************************************************************************/
struct A_SP_s
{
  /* Application analysis OIM attributes */
  unsigned char m_probe_ID;  /* * probe_ID */
  int m_radial_position;  /* - radial_position */
  int m_theta_offset;  /* - theta_offset */
  int m_current_position;  /* - current_position */
  bool m_available;  /* - available */

  /* Relationship storage */
  A_PAA_s * mc_PAA_R2;

  /* State machine current state */
  Escher_StateNumber_t mc_current_state;
};

/*****************************************************************************
 * Object Factory/Manipulation Methods
 ****************************************************************************/
extern void A_SP_FactoryInit( void );
extern A_SP_s * A_SP_Create( void );
/* Note: No instance deletion accessor needed */

#define A_SP_MAX_EXTENT_SIZE 1
extern Escher_ObjectSet_s * pG_A_SP_extent;

/*****************************************************************************
 * Object Relationship Methods
 ****************************************************************************/

/*****************************************************************************
 * Enumeration of state model states for object
 *****************************************************************************/
#define A_SP_STATE_1 1  /* State [1]: 'up' */
#define A_SP_STATE_2 2  /* State [2]: 'down' */
#define A_SP_STATE_3 3  /* State [3]: 'raising' */
#define A_SP_STATE_4 4  /* State [4]: 'lowering' */

/*****************************************************************************
 * Enumeration of state model event numbers
 *****************************************************************************/
#define A_SP_EVENT_SP1 0  /* 'finished_sampling' */
#define A_SP_EVENT_SP2 1  /* 'begin_sampling' */
#define A_SP_EVENT_SP3 2  /* 'probe_in_position' */


/*****************************************************************************
 * State Action Methods
 ****************************************************************************/
extern void A_SP_Action_1( A_SP_s *, const OoaEvent_t * const );
extern void A_SP_Action_2( A_SP_s *, const OoaEvent_t * const );
extern void A_SP_Action_3( A_SP_s *, const OoaEvent_t * const );
extern void A_SP_Action_4( A_SP_s *, const OoaEvent_t * const );

extern void A_SP_Dispatch( const OoaEvent_t * const );

#ifdef	__cplusplus
}
#endif

#endif  /* A_SP_OBJECT_H */


