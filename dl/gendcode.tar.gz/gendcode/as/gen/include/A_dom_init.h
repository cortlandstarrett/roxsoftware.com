/*****************************************************************************
 * File: A_dom_init.h
 *
 * Initialization services for the following domain:
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_DOM_INIT_H
#define A_DOM_INIT_H

#ifdef	__cplusplus
extern "C" {
#endif


#include "e_mechs.h"
#include "e_events.h"

/*****************************************************************************
 * System initialization method for domain: A
 ****************************************************************************/
extern void IntializeDomain_A( void );

/*****************************************************************************
 * System shutdown method for domain: A
 ****************************************************************************/
extern void ShutdownDomain_A( void );

extern void A_DomainDispatcher( OoaEvent_t * );

/****************************************************************************
 * Initialization object methods:
 *
 * Object:    autosampler init  (I)
 * Subsystem: autosampler
 ***************************************************************************/
extern void A_I_InitState_1( void );



#ifdef	__cplusplus
}
#endif

#endif  /* A_DOM_INIT_H */

