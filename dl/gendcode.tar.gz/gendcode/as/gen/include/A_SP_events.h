/*****************************************************************************
 * File:       A_SP_events.h
 *
 * Description:
 * Event classes for the following object:
 *
 * Object:     sampling_probe  (SP)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_SP_EVENTS_H
#define A_SP_EVENTS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "sys_init.h"
#include "e_mechs.h"
#include "e_events.h"

/* Forward reference */
#include "A_objects.h"

/*****************************************************************************
 * Structure: A_SP_Event1_s
 * Instance Directed Event: SP1:'finished_sampling'
 ****************************************************************************/
struct A_SP_Event1_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_SP_Event1_s A_SP_Event1_s;
extern A_SP_Event1_s * New_A_SP_Event1_s( const A_SP_s * const );

/*****************************************************************************
 * Structure: A_SP_Event2_s
 * Instance Directed Event: SP2:'begin_sampling'
 ****************************************************************************/
struct A_SP_Event2_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_SP_Event2_s A_SP_Event2_s;
extern A_SP_Event2_s * New_A_SP_Event2_s( const A_SP_s * const );

/*****************************************************************************
 * Structure: A_SP_Event3_s
 * Instance Directed Event: SP3:'probe_in_position'
 ****************************************************************************/
struct A_SP_Event3_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_SP_Event3_s A_SP_Event3_s;
extern A_SP_Event3_s * New_A_SP_Event3_s( const A_SP_s * const );

/*****************************************************************************
 * A_SP_Events_u
 * Union of events consumable by object's state machine.
 ****************************************************************************/
union A_SP_Events_u
{
  A_SP_Event1_s sp1;
  A_SP_Event2_s sp2;
  A_SP_Event3_s sp3;
};
typedef union A_SP_Events_u A_SP_Events_u;

#ifdef	__cplusplus
}
#endif
#endif  /* A_SP_EVENTS_H */

