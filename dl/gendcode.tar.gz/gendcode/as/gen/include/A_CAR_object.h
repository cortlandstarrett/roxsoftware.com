/*****************************************************************************
 * File:  A_CAR_object.h
 *
 * Object:     carousel  (CAR)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_CAR_OBJECT_H
#define A_CAR_OBJECT_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"
#include "e_events.h"
#include "A_objects.h"

/*****************************************************************************
 * Structure: A_CAR_s
 * Structural representation of application analysis object:
 *   'carousel'  (CAR)
 ****************************************************************************/
struct A_CAR_s
{
  /* Application analysis OIM attributes */
  unsigned char m_carousel_ID;  /* * carousel_ID */
  int m_destination;  /* - destination */
  int m_current_position;  /* - current_position */

  /* Relationship storage */
  A_ROW_s * mc_ROW_R1;

  /* State machine current state */
  Escher_StateNumber_t mc_current_state;
};

/*****************************************************************************
 * Object Factory/Manipulation Methods
 ****************************************************************************/
extern void A_CAR_FactoryInit( void );
extern A_CAR_s * A_CAR_Create( void );
/* Note: No instance deletion accessor needed */

#define A_CAR_MAX_EXTENT_SIZE 1
extern Escher_ObjectSet_s * pG_A_CAR_extent;

/*****************************************************************************
 * Object Relationship Methods
 ****************************************************************************/

/*****************************************************************************
 * Enumeration of state model states for object
 *****************************************************************************/
#define A_CAR_STATE_1 1  /* State [1]: 'resting' */
#define A_CAR_STATE_2 2  /* State [2]: 'going' */

/*****************************************************************************
 * Enumeration of state model event numbers
 *****************************************************************************/
#define A_CAR_EVENT_CAR1 0  /* 'go' */
#define A_CAR_EVENT_CAR2 1  /* 'there' */


/*****************************************************************************
 * State Action Methods
 ****************************************************************************/
extern void A_CAR_Action_1( A_CAR_s *, const OoaEvent_t * const );
extern void A_CAR_Action_2( A_CAR_s *, const OoaEvent_t * const );

extern void A_CAR_Dispatch( const OoaEvent_t * const );

#ifdef	__cplusplus
}
#endif

#endif  /* A_CAR_OBJECT_H */


