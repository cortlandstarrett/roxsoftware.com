/*****************************************************************************
 * File:  A_I_xform.c
 *
 * Description:
 * Transformers declared against the following application analysis object:
 *
 * Object:     autosampler init  (I)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * THIS IS A SKELETON IMPLEMENTATION FILE FOR THE TRANSFORMERS.
 * THESE ARE ONLY TEMPLATES, YOU WILL NEED TO ADD YOUR APPLICATION
 * SPECIFIC CODE TO EACH TRANSFORMER.
 ****************************************************************************/

#include "A_I_xform.h"

/*****************************************************************************
 * Transformer: Run_8051
 ****************************************************************************/
void
A_I_Xform_Run_8051()
{

  /* Insert your implementation code here... */

}

