/*****************************************************************************
 * File:  A_ROW_xform.c
 *
 * Description:
 * Transformers declared against the following application analysis object:
 *
 * Object:     row  (ROW)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * THIS IS A SKELETON IMPLEMENTATION FILE FOR THE TRANSFORMERS.
 * THESE ARE ONLY TEMPLATES, YOU WILL NEED TO ADD YOUR APPLICATION
 * SPECIFIC CODE TO EACH TRANSFORMER.
 ****************************************************************************/

#include "A_ROW_xform.h"

/*****************************************************************************
 * Transformer: convert_dest
 ****************************************************************************/
int
A_ROW_Xform_convert_dest(
    const int x_next_sampling_position,
    const int x_radius )
{
  int result = 0;

  /* Insert your implementation code here... */
  
  return result;
}

