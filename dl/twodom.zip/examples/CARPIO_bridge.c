/*****************************************************************************
 * File:       CARPIO_bridge.c
 *
 * Description:
 *
 * External Entity: 'PIO_1'  (CARPIO)
 ****************************************************************************/


#include "CARPIO_bridge.h"
#include "A_FBO_bridge.h"

static int dest;

/*****************************************************************************
 * Bridge: CARPIO_current_position
 ****************************************************************************/
int
CARPIO_current_position(
    const int ee_car_id )
{
  /* Insert your implementation code here... */
  return dest;
}

/*****************************************************************************
 * Bridge: CARPIO_carousel_spin
 ****************************************************************************/
void
CARPIO_carousel_spin(
    const int ee_car_id,
    const int ee_destination )
{

  /* Insert your implementation code here... */
  dest = ee_destination;
  A_FBO_genC2there();

}


