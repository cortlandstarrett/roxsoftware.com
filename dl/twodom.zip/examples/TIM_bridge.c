/*****************************************************************************
 * File:       TIM_bridge.c
 *
 * Description:
 *
 * External Entity: 'Time'  (TIM)
 ****************************************************************************/


#include "TIM_bridge.h"

/*****************************************************************************
 * Bridge: TIM_current_date
 ****************************************************************************/
Escher_Date_t
TIM_current_date()
{
  Escher_Date_t result;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_create_date
 ****************************************************************************/
Escher_Date_t
TIM_create_date(
    const int ee_day,
    const int ee_hour,
    const int ee_minute,
    const int ee_month,
    const int ee_second,
    const int ee_year )
{
  Escher_Date_t result;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_get_second
 ****************************************************************************/
int
TIM_get_second(
    const Escher_Date_t ee_date )
{
  int result = 0;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_get_minute
 ****************************************************************************/
int
TIM_get_minute(
    const Escher_Date_t ee_date )
{
  int result = 0;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_get_hour
 ****************************************************************************/
int
TIM_get_hour(
    const Escher_Date_t ee_date )
{
  int result = 0;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_get_day
 ****************************************************************************/
int
TIM_get_day(
    const Escher_Date_t ee_date )
{
  int result = 0;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_get_month
 ****************************************************************************/
int
TIM_get_month(
    const Escher_Date_t ee_date )
{
  int result = 0;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_get_year
 ****************************************************************************/
int
TIM_get_year(
    const Escher_Date_t ee_date )
{
  int result = 0;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_current_clock
 ****************************************************************************/
Escher_TimeStamp_t
TIM_current_clock()
{
  Escher_TimeStamp_t result;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_timer_start
 ****************************************************************************/
Escher_Timer_t *
TIM_timer_start(
    const Escher_OoaEvent_s * ee_event_inst,
    const int ee_microseconds )
{
  Escher_Timer_t * result = (Escher_Timer_t *)0;

  /* Insert your implementation code here... */
  Escher_SendEvent( (OoaEvent_t *) ee_event_inst );
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_timer_start_recurring
 ****************************************************************************/
Escher_Timer_t *
TIM_timer_start_recurring(
    const Escher_OoaEvent_s * ee_event_inst,
    const int ee_microseconds )
{
  Escher_Timer_t * result = (Escher_Timer_t *)0;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_timer_remaining_time
 ****************************************************************************/
int
TIM_timer_remaining_time(
    const Escher_Timer_t * ee_timer_inst_ref )
{
  int result = 0;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_timer_reset_time
 ****************************************************************************/
bool
TIM_timer_reset_time(
    const int ee_microseconds,
    const Escher_Timer_t * ee_timer_inst_ref )
{
  bool result = false;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_timer_add_time
 ****************************************************************************/
bool
TIM_timer_add_time(
    const int ee_microseconds,
    const Escher_Timer_t * ee_timer_inst_ref )
{
  bool result = false;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: TIM_timer_cancel
 ****************************************************************************/
bool
TIM_timer_cancel(
    const Escher_Timer_t * ee_timer_inst_ref )
{
  bool result = false;

  /* Insert your implementation code here... */
  
  return result;
}


