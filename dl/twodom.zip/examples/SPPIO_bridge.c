/*****************************************************************************
 * File:       SPPIO_bridge.c
 *
 * Description:
 *
 * External Entity: 'PIO_2'  (SPPIO)
 ****************************************************************************/


#include "SPPIO_bridge.h"
#include "A_FBO_bridge.h"

/*****************************************************************************
 * Bridge: SPPIO_raise_needle
 ****************************************************************************/
int
SPPIO_raise_needle(
    const int ee_probe_id,
    const int ee_radial_position,
    const int ee_theta_offset )
{

  /* Insert your implementation code here... */
  A_FBO_genP3pip();

  return A_position_down_e;
}

/*****************************************************************************
 * Bridge: SPPIO_lower_needle
 ****************************************************************************/
int
SPPIO_lower_needle(
    const int ee_probe_id,
    const int ee_radial_position,
    const int ee_theta_offset )
{

  /* Insert your implementation code here... */
  A_FBO_genP3pip();

  return A_position_up_e;
}


