.//============================================================================
.// $RCSfile: t.smt_sr.chainto1.c,v $
.//
.// Notice:
.// (C) Copyright 1998-2013 Mentor Graphics Corporation
.//     All rights reserved.
.//
.// This document contains confidential and proprietary information and
.// property of Mentor Graphics Corp.  No part of this document may be
.// reproduced without the express written permission of Mentor Graphics Corp.
.//============================================================================
${ws}${te_lnk.te_classGeneratedName} * ${te_lnk.linkage} = ${cast}${te_lnk.left}->${te_lnk.linkage};
.if ( result_equals_start )
${ws}${te_select_related.result_var} = 0;
.end if
${ws}if ( 0 != ${te_lnk.linkage} )${subtypecheck} {
