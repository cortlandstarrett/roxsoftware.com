.if ( "C++" != te_target.language )
${ws}ARCH_shutdown();
.end if
