/*****************************************************************************
 * File:       TIM_bridge.h
 *
 * Description:
 *
 * External Entity: 'Time'  (TIM)
 ****************************************************************************/

#ifndef TIM_BRIDGE_H
#define TIM_BRIDGE_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"

/*****************************************************************************
 * Bridge: TIM_current_date
 ****************************************************************************/
extern Escher_Date_t TIM_current_date( void );

/*****************************************************************************
 * Bridge: TIM_create_date
 ****************************************************************************/
extern Escher_Date_t TIM_create_date(
    const int ee_day,
    const int ee_hour,
    const int ee_minute,
    const int ee_month,
    const int ee_second,
    const int ee_year );

/*****************************************************************************
 * Bridge: TIM_get_second
 ****************************************************************************/
extern int TIM_get_second(
    const Escher_Date_t ee_date );

/*****************************************************************************
 * Bridge: TIM_get_minute
 ****************************************************************************/
extern int TIM_get_minute(
    const Escher_Date_t ee_date );

/*****************************************************************************
 * Bridge: TIM_get_hour
 ****************************************************************************/
extern int TIM_get_hour(
    const Escher_Date_t ee_date );

/*****************************************************************************
 * Bridge: TIM_get_day
 ****************************************************************************/
extern int TIM_get_day(
    const Escher_Date_t ee_date );

/*****************************************************************************
 * Bridge: TIM_get_month
 ****************************************************************************/
extern int TIM_get_month(
    const Escher_Date_t ee_date );

/*****************************************************************************
 * Bridge: TIM_get_year
 ****************************************************************************/
extern int TIM_get_year(
    const Escher_Date_t ee_date );

/*****************************************************************************
 * Bridge: TIM_current_clock
 ****************************************************************************/
extern Escher_TimeStamp_t TIM_current_clock( void );

/*****************************************************************************
 * Bridge: TIM_timer_start
 ****************************************************************************/
extern Escher_Timer_t * TIM_timer_start(
    const Escher_OoaEvent_s * ee_event_inst,
    const int ee_microseconds );

/*****************************************************************************
 * Bridge: TIM_timer_start_recurring
 ****************************************************************************/
extern Escher_Timer_t * TIM_timer_start_recurring(
    const Escher_OoaEvent_s * ee_event_inst,
    const int ee_microseconds );

/*****************************************************************************
 * Bridge: TIM_timer_remaining_time
 ****************************************************************************/
extern int TIM_timer_remaining_time(
    const Escher_Timer_t * ee_timer_inst_ref );

/*****************************************************************************
 * Bridge: TIM_timer_reset_time
 ****************************************************************************/
extern bool TIM_timer_reset_time(
    const int ee_microseconds,
    const Escher_Timer_t * ee_timer_inst_ref );

/*****************************************************************************
 * Bridge: TIM_timer_add_time
 ****************************************************************************/
extern bool TIM_timer_add_time(
    const int ee_microseconds,
    const Escher_Timer_t * ee_timer_inst_ref );

/*****************************************************************************
 * Bridge: TIM_timer_cancel
 ****************************************************************************/
extern bool TIM_timer_cancel(
    const Escher_Timer_t * ee_timer_inst_ref );


#ifdef	__cplusplus
}
#endif

#endif  /* TIM_BRIDGE_H */

