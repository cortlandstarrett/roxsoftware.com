/*****************************************************************************
 * File:       SPPIO_bridge.h
 *
 * Description:
 *
 * External Entity: 'PIO_2'  (SPPIO)
 ****************************************************************************/

#ifndef SPPIO_BRIDGE_H
#define SPPIO_BRIDGE_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"
#include "sys_init.h"

/*****************************************************************************
 * Bridge: SPPIO_raise_needle
 ****************************************************************************/
extern char * SPPIO_raise_needle(
    const int ee_probe_id,
    const int ee_radial_position,
    const int ee_theta_offset );

/*****************************************************************************
 * Bridge: SPPIO_lower_needle
 ****************************************************************************/
extern char * SPPIO_lower_needle(
    const int ee_probe_id,
    const int ee_radial_position,
    const int ee_theta_offset );


#ifdef	__cplusplus
}
#endif

#endif  /* SPPIO_BRIDGE_H */

