/*****************************************************************************
 * File:       CARPIO_bridge.c
 *
 * Description:
 *
 * External Entity: 'PIO_1'  (CARPIO)
 ****************************************************************************/


#include "CARPIO_bridge.h"

/*****************************************************************************
 * Bridge: CARPIO_current_position
 ****************************************************************************/
int
CARPIO_current_position(
    const int ee_car_id )
{
  int result = 0;

  /* Insert your implementation code here... */
  
  return result;
}

/*****************************************************************************
 * Bridge: CARPIO_carousel_spin
 ****************************************************************************/
void
CARPIO_carousel_spin(
    const int ee_car_id,
    const int ee_destination )
{

  /* Insert your implementation code here... */

}


