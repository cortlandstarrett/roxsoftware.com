/*****************************************************************************
 * File:  sys_evpool.c
 *
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include <stdlib.h>

#include "sys_init.h"

#include "e_mechs.h"
#include "e_events.h"
#include "e_objset.h"

/* Include header(s) of domain level events union. */
#include "A_events.h"

/*****************************************************************************
 * Structure: SystemOoaEvents_u
 * 'Super-union' of all OOA events in the system. For translation patterns
 * which can not accept dynamic memory allocation for OOA events, this union
 * is used to predetermine the maximum size of any OOA event in the system.
 ****************************************************************************/
union SystemOoaEvents_u
{
  OoaEvent_t mc_event_base;
  A_DomainEvents_u mc_events_in_domain_A;
};
typedef union SystemOoaEvents_u SystemOoaEvents_u;

/*****************************************************************************
 ****************************************************************************/
typedef struct EventPool_s EventPool_t;
struct EventPool_s
{
  EventPool_t * next;
  OoaEvent_t  * event;
};

/*****************************************************************************
 ****************************************************************************/
typedef struct EnqueuedOoaEvent_s EnqueuedOoaEvent_s;
struct EnqueuedOoaEvent_s
{
  EnqueuedOoaEvent_s * next;
  OoaEvent_t         * event;
};

typedef struct OoaEventQueue_s OoaEventQueue_s;
struct OoaEventQueue_s
{
  EnqueuedOoaEvent_s * head;
  EnqueuedOoaEvent_s * tail;
};

/*****************************************************************************
 * Pre-allocated memory pool for OOA events.
 ****************************************************************************/
static SystemOoaEvents_u aSG_ooa_event_pool[ SYS_MAX_OOA_EVENTS ];

static EventPool_t   aSG_event_node[ SYS_MAX_OOA_EVENTS ];
static EventPool_t * pSG_free_event_list = (EventPool_t *) 0;

/*****************************************************************************
 ****************************************************************************/
void
InitializeOoaEventPool()
{
  unsigned int i;

  /* String event containers together into a singly linked list. */
  pSG_free_event_list = &aSG_event_node[ 0 ];
  for ( i = 0; i < SYS_MAX_OOA_EVENTS; i++ )
  {
    aSG_event_node[ i ].next  = &(aSG_event_node[ i + 1 ]);
    aSG_event_node[ i ].event = (OoaEvent_t *) &(aSG_ooa_event_pool[ i ]);
  }

  aSG_event_node[ SYS_MAX_OOA_EVENTS - 1 ].next = (EventPool_t *) 0;
}

/*****************************************************************************
 * Escher_AllocateOoaEvent
 * Note: 'event_size' unused, reserved for future use.
 ****************************************************************************/
OoaEvent_t *
Escher_AllocateOoaEvent( const unsigned int event_size )
{
  OoaEvent_t  * event;
  EventPool_t * slot;

  slot = pSG_free_event_list;        /* Get the next available event slot. */

  if ( ! slot )
  {
    printf( "%s #%d: Event pool empty!\n", __FILE__, __LINE__ );
    exit( -1 );
  }

  event = slot->event;               /* Get event ptr from allocated slot. */
  pSG_free_event_list = slot->next;  /* Update next available event slot.  */
  slot->next = (EventPool_t *) 0;    /* This slot no longer on free list.  */

  return event;
}

/*****************************************************************************
 * Escher_DeleteOoaEvent
 ****************************************************************************/
void
Escher_DeleteOoaEvent( void * event )
{
  unsigned int i;
  EventPool_t * slot;
  EventPool_t * owning_slot = 0;

  /* Find the slot which 'owns' this event. */
  slot = &(aSG_event_node[ 0 ]);
  for ( i = 0; i < SYS_MAX_OOA_EVENTS; i++ )
  {
    if ( slot->event == (OoaEvent_t *) event )
    {
      owning_slot = slot;
      break;
    }
    else
      ++slot;
  }

  /* Swizzle the slot positions to reclaim the event. */
  if ( pSG_free_event_list )
    owning_slot->next = pSG_free_event_list;
  else
    owning_slot->next = (EventPool_t *) 0;

  pSG_free_event_list = owning_slot;
}


/*****************************************************************************
 ****************************************************************************/
static EnqueuedOoaEvent_s aSG_non_self_events[ SYS_MAX_NON_SELF_EVENTS + 1 ];
static OoaEventQueue_s    sSG_non_self_event_queue;

/*****************************************************************************
 ****************************************************************************/
void
InitializeOoaNonSelfEventQueue()
{
  unsigned char i;
  sSG_non_self_event_queue.head = &(aSG_non_self_events[ 0 ]);
  sSG_non_self_event_queue.tail = &(aSG_non_self_events[ 0 ]);

  for ( i = 0; i < ( SYS_MAX_NON_SELF_EVENTS ); i++ )
    aSG_non_self_events[ i ].next = &(aSG_non_self_events[ i + 1 ]);

  aSG_non_self_events[ SYS_MAX_NON_SELF_EVENTS ].next = &(aSG_non_self_events[ 0 ]);
}

/*****************************************************************************
 ****************************************************************************/
void
Escher_SendEvent( OoaEvent_t * event )
{
  /* Note: Need to check for over flow! */
  if ( sSG_non_self_event_queue.tail->next == sSG_non_self_event_queue.head )
  {
    printf( "%s #%d: Event Queue Overflow!\n", __FILE__, __LINE__ );
    exit( -1 );
  }

  sSG_non_self_event_queue.tail->event = event;
  sSG_non_self_event_queue.tail = sSG_non_self_event_queue.tail->next;
}

/*****************************************************************************
 ****************************************************************************/
OoaEvent_t *
DequeueOoaNonSelfEvent()
{
  OoaEvent_t * event = 0;
  if ( sSG_non_self_event_queue.head != sSG_non_self_event_queue.tail )
  {
    event = sSG_non_self_event_queue.head->event;
    sSG_non_self_event_queue.head = sSG_non_self_event_queue.head->next;
  }
  return event;
}


/*****************************************************************************
 ****************************************************************************/
static EnqueuedOoaEvent_s self_events[ SYS_MAX_SELF_EVENTS + 1 ];
static OoaEventQueue_s    self_event_queue;

/*****************************************************************************
 ****************************************************************************/
void
InitializeOoaSelfEventQueue()
{
  unsigned char i;
  self_event_queue.head = &(self_events[ 0 ]);
  self_event_queue.tail = &(self_events[ 0 ]);

  for ( i = 0; i < ( SYS_MAX_SELF_EVENTS ); i++ )
    self_events[ i ].next = &(self_events[ i + 1 ]);

  self_events[ SYS_MAX_SELF_EVENTS ].next = &(self_events[ 0 ]);
}

/*****************************************************************************
 * Enqueue event to tail of list.
 ****************************************************************************/
void
Escher_SendSelfEvent( OoaEvent_t * event )
{
  self_event_queue.tail->event = event;
  self_event_queue.tail = self_event_queue.tail->next;
}

/*****************************************************************************
 * Dequeue event at head of list.
 ****************************************************************************/
OoaEvent_t *
DequeueOoaSelfEvent()
{
  OoaEvent_t * event = 0;
  if ( self_event_queue.head != self_event_queue.tail )
  {
    event = self_event_queue.head->event;
    self_event_queue.head = self_event_queue.head->next;
  }
  return event;
}


