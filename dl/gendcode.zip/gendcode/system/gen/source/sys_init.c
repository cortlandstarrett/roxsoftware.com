/*****************************************************************************
 * File:  sys_init.c
 *
 * Description:
 * Main entrance to the wild thing...
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include <stdlib.h>

#include "sys_init.h"

#include "e_mechs.h"
#include "e_events.h"
#include "e_objset.h"

#include "sys_user_co.h"

#include "A_dom_init.h"

/*****************************************************************************
 ****************************************************************************/
static const DomainDispatcher_t DomainDispatcherTable[ 2 ] =
{
  0,
  (DomainDispatcher_t) A_DomainDispatcher
};

extern void RunApplicationInitSequence( void );

static bool run_flag = true;

/*****************************************************************************
 * main process
 ****************************************************************************/
int
main ( int argc, char * argv[] )
{
  OoaEvent_t * event;

  /* Execute user supplied system initialization. */
  UserInitializationCallout();

  /* Execute generated system initialization phase. */
  SystemLevelInitialization();

  /* Execute OOA domain specific initialization phase(s). */
  ApplicationLevelInitialization();

  /* Execute application analysis initialization phase(s). */
  UserPreOoaInitializationCallout();   /* User supplied pre-init.  */
  RunApplicationInitSequence();        /* OOA init object states.  */
  UserPostOoaInitializationCallout();  /* User supplied post-init. */

  /* Start consuming events and dispatching background processes. */
  while ( run_flag )
  {
    /* User supplied background processing callout. */
    UserBackgroundProcessingCallout();
    
    /* Dispatch one OOA non-self directed event. */
    if ( ( event = DequeueOoaNonSelfEvent() ) != 0 )
    {
      ( *DomainDispatcherTable[ GetEventDestDomainNumber( event ) ] )( event );
      if ( GetFsmReleasesEvent( event ) )
        Escher_DeleteOoaEvent( event );
    }

    /* Dispatch all OOA self directed events. */
    while ( ( event = DequeueOoaSelfEvent() ) != 0 )
    {
      ( *DomainDispatcherTable[ GetEventDestDomainNumber( event ) ] )( event );
      Escher_DeleteOoaEvent( event );
    }
  }

  /* Shutdown phasing */
  UserPreShutdownCallout();
  ApplicationLevelShutdown();
  SystemLevelShutdown();
  UserPostShutdownCallout();

  return 0;
}
 
/*****************************************************************************
 * SystemLevelInitialization
 ****************************************************************************/
void
SystemLevelInitialization()
{
  /* Initialize the container pool. */
  Escher_SetFactoryInit();

  /* Initialize OOA event pool and queues. */
  InitializeOoaEventPool();
  InitializeOoaNonSelfEventQueue();
  InitializeOoaSelfEventQueue();
}

/*****************************************************************************
 * ApplicationLevelInitialization
 ****************************************************************************/
void
ApplicationLevelInitialization()
{
   /* Initialize all the domains */
  IntializeDomain_A();
}

/*****************************************************************************
 * SystemLevelShutdown
 ****************************************************************************/
void
SystemLevelShutdown()
{}

/*****************************************************************************
 * ApplicationLevelShutdown
 ****************************************************************************/
void
ApplicationLevelShutdown()
{
   /* Shutdown all the domains */
  ShutdownDomain_A();
}

