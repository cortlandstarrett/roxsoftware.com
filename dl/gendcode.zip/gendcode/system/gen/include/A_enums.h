/*****************************************************************************
 * File:  A_enums.h
 *
 * Description:
 *   Enumerated data types in the application analysis of domain:
 *
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_ENUMS_H
#define A_ENUMS_H

#ifdef	__cplusplus
extern "C" {
#endif


/*****************************************************************************
 * Enumerated Data Type: 'position'
 ****************************************************************************/
#define A_position__UNITIALIZED__e  0
#define A_position_up_e   1
#define A_position_down_e   2

#ifdef	__cplusplus
}
#endif

#endif  /* A_ENUMS_H */
