/*****************************************************************************
 * File:  A_F_bridge.h
 *
 * Description:
 * Bridge implementation for the following application analysis object:
 *
 * Object:     FBO_UI  (F)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_F_BRIDGE_H
#define A_F_BRIDGE_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"
#include "e_events.h"
#include "sys_init.h"

/*****************************************************************************
 * Synchronous Bridge Methods
 ****************************************************************************/

/*****************************************************************************
 * Bridge: FBO_r_string
 ****************************************************************************/
extern char * A_F_FBO_r_string( void );

/*****************************************************************************
 * Bridge: genC2there
 ****************************************************************************/
extern void A_F_genC2there( void );

/*****************************************************************************
 * Bridge: genP3pip
 ****************************************************************************/
extern void A_F_genP3pip( void );


#ifdef	__cplusplus
}
#endif

#endif  /* A_F_BRIDGE_H */
