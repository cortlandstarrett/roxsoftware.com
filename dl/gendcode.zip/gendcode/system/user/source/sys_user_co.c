/*****************************************************************************
 * File: sys_user_co.c
 *
 * Description:
 * Function definitions for user supplied (non-translated) call out entry
 * points in the generated application.
 *
 *
 * Notice:
 * (C) Copyright 1999 ROX Software, Inc.
 *     All rights reserved.
 *
 * This document contains confidential and proprietary information and
 * property of ROX Software, Inc.  No part of this document may be
 * reproduced without the express written permission of ROX Software, Inc.
 ****************************************************************************/

 #include "sys_user_co.h"

 /*****************************************************************************
 * UserInitializationCallout
 *
 * This function is invoked at the immediate begining of application
 * initialization. It is the very first function to be executed at system
 * startup.
 * User supplied implementation of this function should be restricted to
 * things like memory initialization, early hardware duties, etc.
 *
 ****************************************************************************/
void UserInitializationCallout()
{
  /* Insert implementation specific code here */
}

/*****************************************************************************
 * UserPreOoaInitializationCallout
 *
 * This function is invoked immediately prior to executing any OOA application
 * analysis initialization objects.
 *
 ****************************************************************************/
void UserPreOoaInitializationCallout()
{
  /* Insert implementation specific code here */
}

/*****************************************************************************
 * UserPostOoaInitializationCallout
 *
 * This function is invoked immediately after executing any OOA application
 * analysis initialization objects.
 * When this callout function returns, the system dispatcher will allow the
 * OOA application analysis state models to start consuming events.
 *
 ****************************************************************************/
void UserPostOoaInitializationCallout()
{
  /* Insert implementation specific code here */
}

/*****************************************************************************
 * UserBackgroundProcessingCallout
 *
 * This function is invoked once during each loop execution of the system
 * dispather.
 * It is invoked at the 'top' of the system dispatcher loop, immediately
 * prior to dispatching any OOA application analysis events.
 *
 ****************************************************************************/
void UserBackgroundProcessingCallout()
{
  /* Insert implementation specific code here */
}

/*****************************************************************************
 * UserPreShutdownCallout
 *
 * This function is invoked at termination of the system dispatcher, but
 * prior to performing any OOA application analysis shutdown sequencing.
 *
 ****************************************************************************/
void UserPreShutdownCallout()
{
  /* Insert implementation specific code here */
}

/*****************************************************************************
 * UserPostShutdownCallout
 *
 * This function is invoked immediately before application exit.
 *
 ****************************************************************************/
void UserPostShutdownCallout()
{
  /* Insert implementation specific code here */
}



