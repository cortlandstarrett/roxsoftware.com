/*****************************************************************************
 * File:  A_I_xform.h
 *
 * Description:
 * Transformers declared against the following application analysis object:
 *
 * Object:     autosampler init  (I)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_I_XFORM_H
#define A_I_XFORM_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"

/*****************************************************************************
 * Transformer: Run_8051
 ****************************************************************************/
extern void A_I_Xform_Run_8051( void );

#ifdef	__cplusplus
}
#endif

#endif  /* A_I_XFORM_H */

