/*****************************************************************************
 * File:       A_CAR_events.h
 *
 * Description:
 * Event classes for the following object:
 *
 * Object:     carousel  (CAR)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_CAR_EVENTS_H
#define A_CAR_EVENTS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "sys_init.h"
#include "e_mechs.h"
#include "e_events.h"

/* Forward reference */
#include "A_objects.h"

/*****************************************************************************
 * Structure: A_CAR_Event1_s
 * Instance Directed Event: CAR1:'go'
 ****************************************************************************/
struct A_CAR_Event1_s
{
  OoaEvent_t mc_event_base;
  int m_destination;
};
typedef struct A_CAR_Event1_s A_CAR_Event1_s;
extern A_CAR_Event1_s * New_A_CAR_Event1_s( const A_CAR_s * const );

/*****************************************************************************
 * Structure: A_CAR_Event2_s
 * Instance Directed Event: CAR2:'there'
 ****************************************************************************/
struct A_CAR_Event2_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_CAR_Event2_s A_CAR_Event2_s;
extern A_CAR_Event2_s * New_A_CAR_Event2_s( const A_CAR_s * const );

/*****************************************************************************
 * A_CAR_Events_u
 * Union of events consumable by object's state machine.
 ****************************************************************************/
union A_CAR_Events_u
{
  A_CAR_Event1_s car1;
  A_CAR_Event2_s car2;
};
typedef union A_CAR_Events_u A_CAR_Events_u;

#ifdef	__cplusplus
}
#endif
#endif  /* A_CAR_EVENTS_H */

