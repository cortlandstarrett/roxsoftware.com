/*****************************************************************************
 * File:       A_PAA_ASG_events.h
 *
 * Description:
 * Event classes for the following object Assigner:
 *
 * Object:     probe_assignment  (PAA)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_PAA_ASG_EVENTS_H
#define A_PAA_ASG_EVENTS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "sys_init.h"
#include "e_mechs.h"
#include "e_events.h"

/* Forward reference */
#include "A_objects.h"

/*****************************************************************************
 * Structure: A_PAA_AsgEvent1_s
 * Assigner Event: PAA_A1:'row_needs_probe'
 ****************************************************************************/
struct A_PAA_AsgEvent1_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_PAA_AsgEvent1_s A_PAA_AsgEvent1_s;
extern A_PAA_AsgEvent1_s * New_A_PAA_AsgEvent1_s( void );

/*****************************************************************************
 * Structure: A_PAA_AsgEvent2_s
 * Assigner Event: PAA_A2:'probe_available'
 ****************************************************************************/
struct A_PAA_AsgEvent2_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_PAA_AsgEvent2_s A_PAA_AsgEvent2_s;
extern A_PAA_AsgEvent2_s * New_A_PAA_AsgEvent2_s( void );

/*****************************************************************************
 * Assigner Event: PAA_A4:'carousel_complete'
 * WARNING: Event not used in application - no code generated!
 ****************************************************************************/

/*****************************************************************************
 * Structure: A_PAA_AsgEvent3_s
 * Assigner Event: PAA_A3:'probe_assigned'
 ****************************************************************************/
struct A_PAA_AsgEvent3_s
{
  OoaEvent_t mc_event_base;
  /* Note: No supplemental data for this event */
};
typedef struct A_PAA_AsgEvent3_s A_PAA_AsgEvent3_s;
extern A_PAA_AsgEvent3_s * New_A_PAA_AsgEvent3_s( void );

/*****************************************************************************
 * A_PAA_ASG_Events_u
 * Union of events consumable by object's state machine.
 ****************************************************************************/
union A_PAA_ASG_Events_u
{
  A_PAA_AsgEvent1_s paa_a1;
  A_PAA_AsgEvent2_s paa_a2;
  A_PAA_AsgEvent3_s paa_a3;
};
typedef union A_PAA_ASG_Events_u A_PAA_ASG_Events_u;

#ifdef	__cplusplus
}
#endif
#endif  /* A_PAA_ASG_EVENTS_H */

