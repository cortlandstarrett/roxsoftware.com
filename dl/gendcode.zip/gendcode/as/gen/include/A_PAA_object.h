/*****************************************************************************
 * File:  A_PAA_object.h
 *
 * Object:     probe_assignment  (PAA)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#ifndef A_PAA_OBJECT_H
#define A_PAA_OBJECT_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "e_mechs.h"
#include "A_objects.h"

/*****************************************************************************
 * Structure: A_PAA_s
 * Structural representation of application analysis object:
 *   'probe_assignment'  (PAA)
 ****************************************************************************/
struct A_PAA_s
{
  /* Application analysis OIM attributes */
  unsigned char m_probe_ID;  /* * probe_ID (R2) */
  int m_radius;  /* * radius (R2) */

  /* Relationship storage */
  A_ROW_s * mc_ROW_R2;
  A_SP_s * mc_SP_R2;
};

/*****************************************************************************
 * Object Factory/Manipulation Methods
 ****************************************************************************/
extern void A_PAA_FactoryInit( void );
extern A_PAA_s * A_PAA_Create( void );
extern void A_PAA_Delete( A_PAA_s * );

#define A_PAA_MAX_EXTENT_SIZE 2
extern Escher_ObjectSet_s * pG_A_PAA_extent;

/*****************************************************************************
 * Object Relationship Methods
 ****************************************************************************/

extern void A_PAA_R2_Link( A_ROW_s *, A_SP_s *, A_PAA_s * );
extern void A_PAA_R2_Unlink( A_ROW_s *, A_SP_s *, A_PAA_s * );


#ifdef	__cplusplus
}
#endif

#endif  /* A_PAA_OBJECT_H */


