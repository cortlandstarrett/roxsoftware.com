/*****************************************************************************
 * File:       A_PAA_ASG_events.c
 *
 * Description:
 * Event classes for the following object Assigner:
 *
 * Object:     probe_assignment  (PAA)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "A_objects.h"
#include "A_PAA_ASG.h"
#include "A_PAA_ASG_events.h"

/*****************************************************************************
 * New_A_PAA_AsgEvent1_s
 ****************************************************************************/
A_PAA_AsgEvent1_s *
New_A_PAA_AsgEvent1_s()
{
  A_PAA_AsgEvent1_s * event = (A_PAA_AsgEvent1_s *) Escher_AllocateOoaEvent( sizeof( A_PAA_AsgEvent1_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_PAA_ASSIGNER_ID );
  SetOoaEventNumber( event, A_PAA_ASG_EVENT_PAA_A1 );
  ClearOoaEventFlags( event );
  SetIsAssignerEvent( event );
  SetEventTargetInstance( event, 0 );

  return event;
}

/*****************************************************************************
 * New_A_PAA_AsgEvent2_s
 ****************************************************************************/
A_PAA_AsgEvent2_s *
New_A_PAA_AsgEvent2_s()
{
  A_PAA_AsgEvent2_s * event = (A_PAA_AsgEvent2_s *) Escher_AllocateOoaEvent( sizeof( A_PAA_AsgEvent2_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_PAA_ASSIGNER_ID );
  SetOoaEventNumber( event, A_PAA_ASG_EVENT_PAA_A2 );
  ClearOoaEventFlags( event );
  SetIsAssignerEvent( event );
  SetEventTargetInstance( event, 0 );

  return event;
}


/*****************************************************************************
 * New_A_PAA_AsgEvent3_s
 ****************************************************************************/
A_PAA_AsgEvent3_s *
New_A_PAA_AsgEvent3_s()
{
  A_PAA_AsgEvent3_s * event = (A_PAA_AsgEvent3_s *) Escher_AllocateOoaEvent( sizeof( A_PAA_AsgEvent3_s ) );

  SetEventDestDomainNumber( event, A_DOMAIN_ID );
  SetEventDestObjectNumber( event, A_PAA_ASSIGNER_ID );
  SetOoaEventNumber( event, A_PAA_ASG_EVENT_PAA_A3 );
  ClearOoaEventFlags( event );
  SetIsAssignerEvent( event );
  SetEventTargetInstance( event, 0 );

  return event;
}


