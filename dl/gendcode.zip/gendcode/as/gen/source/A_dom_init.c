/*****************************************************************************
 * File: A_dom_init.c
 *
 * Initialization services for the following domain:
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/


#include "A_objects.h"
#include "A_enums.h"
#include "A_CAR_events.h"
#include "A_ROW_events.h"
#include "A_SP_events.h"
#include "A_I_xform.h"

#include "A_dom_init.h"

#include "A_CAR_object.h"
#include "A_ROW_object.h"
#include "A_SP_object.h"
#include "A_PAA_object.h"
#include "A_PAA_ASG.h"


/*****************************************************************************
 * Initialization Object: autosampler init  (I)
 *
 * State [1]: 'starting'
 ****************************************************************************/
void
A_I_InitState_1()
{
  A_CAR_s * v1;  /* car */
  A_ROW_s * v2;  /* row */
  A_SP_s * v3;  /* probe */

  /* TRANSFORM I::Run_8051() */
  A_I_Xform_Run_8051();

  /* CREATE OBJECT INSTANCE car OF CAR */
  v1 = A_CAR_Create();

  /* ASSIGN car.carousel_ID = 10 */
  v1->m_carousel_ID = 10;

  /* ASSIGN car.current_position = 10 */
  v1->m_current_position = 10;

  /* CREATE OBJECT INSTANCE row OF ROW */
  v2 = A_ROW_Create();

  /* RELATE row TO car ACROSS R1 */
  A_ROW_R1_Link( v1, v2 );

  /* ASSIGN row.radius = 10 */
  v2->m_radius = 10;

  /* ASSIGN row.current_sampling_position = 0 */
  v2->m_current_sampling_position = 0;

  /* ASSIGN row.maximum_sampling_positions = 200 */
  v2->m_maximum_sampling_positions = 200;

  /* ASSIGN row.sampling_time = 5000000 */
  v2->m_sampling_time = 5000000;

  /* ASSIGN row.needs_probe = FALSE */
  v2->m_needs_probe = false;

  /* CREATE OBJECT INSTANCE probe OF SP */
  v3 = A_SP_Create();

  /* ASSIGN probe.probe_ID = 1 */
  v3->m_probe_ID = 1;

  /* ASSIGN probe.radial_position = 20 */
  v3->m_radial_position = 20;

  /* ASSIGN probe.theta_offset = 40 */
  v3->m_theta_offset = 40;

  /* ASSIGN probe.current_position = 'up' */
  v3->m_current_position = A_position_up_e;

  /* ASSIGN probe.available = TRUE */
  v3->m_available = true;

  /* GENERATE ROW1:'probe_request'() TO row */
  {
    A_ROW_Event1_s * event4 = New_A_ROW_Event1_s( v2 );
    Escher_SendEvent( (OoaEvent_t *)event4 );
  }

}


/*****************************************************************************
 * Array of pointers to the object event dispather method.
 * Index is the (MC enumerated) number of the state model.
 ****************************************************************************/
static const EventTaker_t
A_EventDispatcher[ A_STATE_MODELS + 1 ] =
{
  (EventTaker_t) 0, /* Unused - instrumentation hook */
  (EventTaker_t) A_CAR_Dispatch,
  (EventTaker_t) A_ROW_Dispatch,
  (EventTaker_t) A_SP_Dispatch,
  (EventTaker_t) A_PAA_ASG_Dispatch
};


/*****************************************************************************
 ****************************************************************************/
void 
A_DomainDispatcher( OoaEvent_t * event )
{
  ( *A_EventDispatcher[ GetEventDestObjectNumber( event ) ] )( event );
}

/*****************************************************************************
 * System initialization method for domain: A
 ****************************************************************************/
void
IntializeDomain_A()
{
  /* Open object factories */
  A_CAR_FactoryInit();
  A_ROW_FactoryInit();
  A_SP_FactoryInit();
  A_PAA_FactoryInit();
  /* Open object assigner singletons */
  A_PAA_AssignerInit();
}

/*****************************************************************************
 * System shutdown method for domain: A
 ****************************************************************************/
void
ShutdownDomain_A()
{
  /* Close object factories */
  /* Close object assigner singletons */
}

