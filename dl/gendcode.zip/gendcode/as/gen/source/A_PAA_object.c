/*****************************************************************************
 * File:  A_PAA_object.c
 *
 * Object:     probe_assignment  (PAA)
 * Subsystem:  autosampler
 * Domain:     A
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "A_objects.h"
#include "A_PAA_object.h"
#include "A_ROW_object.h"
#include "A_SP_object.h"
    
/*****************************************************************************
 * Statically allocate space for the instance population for this object.
 * Allocate space for the object and its attributes.
 * Depending on the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 ****************************************************************************/
static A_PAA_s A_PAA_ObjectPool_s[ A_PAA_MAX_EXTENT_SIZE ];
static Escher_ObjectSet_s A_PAA_ActiveExtent_s; /* set container */
Escher_ObjectSet_s * pG_A_PAA_extent;
static Escher_ObjectSet_s * p_A_PAA_inanimate;

/*****************************************************************************
 * Initialize object factory services.
 ****************************************************************************/
void
A_PAA_FactoryInit()
{
  unsigned int i;
  Escher_ObjectSet_s s;
  Escher_InitSet( &s );

  /* Initialize object instance storage free pool (inanimate list)
   * by linking the containoids into a linear, null-terminated,
   * singly linked list.  */
  for ( i = 0; i < A_PAA_MAX_EXTENT_SIZE; i++ )
  {
    Escher_SetInsertElement( &s, &A_PAA_ObjectPool_s[ i ] );
  }
  p_A_PAA_inanimate = s.next; /* free list head */

  /* Initialize object class extent (animate list) to empty.  */
  Escher_InitSet( &A_PAA_ActiveExtent_s );
  pG_A_PAA_extent = &A_PAA_ActiveExtent_s;
}


/*****************************************************************************
 * Object Creation Accessor
 ****************************************************************************/
A_PAA_s *
A_PAA_Create()
{
  Escher_ObjectSet_s * node;
  A_PAA_s * self;

  /* Acquire instance storage from object free pool.  */
  node = p_A_PAA_inanimate;
  p_A_PAA_inanimate = p_A_PAA_inanimate->next;
  self = (A_PAA_s *) node->object;

  /* Initialize application analysis object attributes.  */
  self->m_probe_ID = 0;
  self->m_radius = 0;

  /* Initialize relationship storage */
  self->mc_ROW_R2 = 0;
  self->mc_SP_R2 = 0;


  /* Insert instance into active extent (animate).  */
  node->next = pG_A_PAA_extent->next;
  pG_A_PAA_extent->next = node;

  return self;
}


/*****************************************************************************
 * Object Deletion Accessor
 ****************************************************************************/
void
A_PAA_Delete( A_PAA_s * self )
{
  Escher_ObjectSet_s * slot;

  if ( !self ) return;

  /* Remove instance from object extent.  */
  slot = Escher_SetRemoveNode( pG_A_PAA_extent, self );

  /* Release relationship storage */
  self->mc_ROW_R2 = 0;
  self->mc_SP_R2 = 0;
  /* Reset identifying attribute(s) to system default values */
  self->m_radius = 0;
  self->m_probe_ID = 0;

  /* Release instance storage back to object free pool.  */
  slot->next = p_A_PAA_inanimate;
  p_A_PAA_inanimate = slot;
}

/*****************************************************************************
 * RELATE ROW TO SP ACROSS R2 USING PAA
 ****************************************************************************/
void
A_PAA_R2_Link( A_ROW_s * aone, A_SP_s * aoth, A_PAA_s * assr )
{
  assr->m_radius = aone->m_radius;
  assr->m_probe_ID = aoth->m_probe_ID;
  /* Initialize optimized relationship storage extended attributes */
  assr->mc_ROW_R2 = aone;
  assr->mc_SP_R2 = aoth;
  aone->mc_PAA_R2 = assr;
  aoth->mc_PAA_R2 = assr;
}

/*****************************************************************************
 * UNRELATE ROW FROM SP ACROSS R2 USING PAA
 ****************************************************************************/
void
A_PAA_R2_Unlink( A_ROW_s * aone, A_SP_s * aoth, A_PAA_s * assr )
{
  assr->m_probe_ID = 0;
  assr->m_radius = 0;

  assr->mc_ROW_R2 = (A_ROW_s *)0;
  assr->mc_SP_R2 = (A_SP_s *)0;
  aone->mc_PAA_R2 = (A_PAA_s *)0;
  aoth->mc_PAA_R2 = (A_PAA_s *)0;
}



