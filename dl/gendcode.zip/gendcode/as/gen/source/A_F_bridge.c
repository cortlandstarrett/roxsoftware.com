/*****************************************************************************
 * File:  A_F_bridge.c
 *
 * Description:
 * Bridge implementation for the following application analysis object:
 *
 * Object:     FBO_UI  (F)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "e_mechs.h"
#include "e_events.h"
#include "A_objects.h"
#include "sys_init.h"
#include "A_CAR_object.h"
#include "A_CAR_events.h"
#include "A_SP_object.h"
#include "A_SP_events.h"
#include "A_F_bridge.h"

/*****************************************************************************
 * Bridge method: A_F_FBO_r_string
 ****************************************************************************/
char *
A_F_FBO_r_string( void )
{
  typedef struct bridge_rval_s
  {
     char m_FBO_r_string[ SYS_MAX_STRING_LEN ];
  } bridge_rval_s;

  static bridge_rval_s bridge_rval;
  bridge_rval_s * self = &bridge_rval;

  /* ASSIGN SELF.FBO_r_string = 'ROX Solid!' */
  strncpy( self->m_FBO_r_string, "ROX Solid!", SYS_MAX_STRING_LEN );

  return bridge_rval.m_FBO_r_string;
}

/*****************************************************************************
 * Bridge method: A_F_genC2there
 ****************************************************************************/
void
A_F_genC2there( void )
{
  A_CAR_s * v1;  /* c */

  /* SELECT ANY c FROM INSTANCES OF CAR */
  v1 = (A_CAR_s *)Escher_SetGetAny( pG_A_CAR_extent );

  /* GENERATE CAR2:'there'() TO c */
  {
    A_CAR_Event2_s * event2 = New_A_CAR_Event2_s( v1 );
    Escher_SendEvent( (OoaEvent_t *)event2 );
  }

}

/*****************************************************************************
 * Bridge method: A_F_genP3pip
 ****************************************************************************/
void
A_F_genP3pip( void )
{
  A_SP_s * v3;  /* p */

  /* SELECT ANY p FROM INSTANCES OF SP */
  v3 = (A_SP_s *)Escher_SetGetAny( pG_A_SP_extent );

  /* GENERATE SP3:'probe_in_position'() TO p */
  {
    A_SP_Event3_s * event4 = New_A_SP_Event3_s( v3 );
    Escher_SendEvent( (OoaEvent_t *)event4 );
  }

}
