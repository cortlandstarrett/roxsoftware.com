/*****************************************************************************
 * File:       A_CAR_actions.c
 *
 * Description:
 * State actions methods implementation for the following object:
 *
 * Object:     carousel  (CAR)
 * Domain:     A
 * Subsystem:  autosampler
 * Repository: as.ooa
 *
 * Notice:
 *   (C) Copyright 1999 ROX Software, Inc.
 *   All rights reserved.
 *
 * Model Compiler: MC3020  V1.0.0
 * Serial Number:  302010099031401
 *
 * Warnings:
 *   !!! THIS IS AN AUTO-GENERATED FILE. PLEASE DO NOT EDIT. !!!
 ****************************************************************************/

#include "e_mechs.h"
#include "e_events.h"
#include "A_objects.h"
#include "A_enums.h"
#include "A_CAR_object.h"
#include "A_CAR_events.h"
#include "A_ROW_object.h"
#include "A_ROW_events.h"
#include "A_SP_object.h"
#include "A_SP_events.h"
#include "CARPIO_bridge.h"

/*****************************************************************************
 * State [1]: 'resting'
 ****************************************************************************/
void
A_CAR_Action_1( A_CAR_s * self, const OoaEvent_t * const event )
{
  A_ROW_s * v3;  /* row */

  /* ASSIGN SELF.current_position = CARPIO::current_position(car_id:SELF.carousel_ID) */
  self->m_current_position = CARPIO_current_position( self->m_carousel_ID );

  /* IF (SELF.current_position != SELF.destination) */
  if ( (self->m_current_position != self->m_destination) )
  {  }
  /* END IF */

  /* SELECT ONE row RELATED BY SELF->ROW[R1] */
  v3 = self->mc_ROW_R1;

  /* GENERATE ROW3:'carousel_move_complete'() TO row */
  {
    A_ROW_Event3_s * event4 = New_A_ROW_Event3_s( v3 );
    Escher_SendEvent( (OoaEvent_t *)event4 );
  }

}

/*****************************************************************************
 * State [2]: 'going'
 ****************************************************************************/
void
A_CAR_Action_2( A_CAR_s * self, const OoaEvent_t * const event )
{
  A_CAR_Event1_s * rcvd_evt = (A_CAR_Event1_s *)event;
  A_SP_s * v8;  /* probe */
  int v5;  /* delta */

  /* ASSIGN SELF.destination = RCVD_EVT.destination */
  self->m_destination = rcvd_evt->m_destination;

  /* ASSIGN delta = SELF.destination - SELF.current_position */
  v5 = self->m_destination - self->m_current_position;

  /* IF (delta == 0) */
  if ( (v5 == 0) )
  {
    /* GENERATE CAR2:'there'() TO SELF */
    {
      A_CAR_Event2_s * event6 = New_A_CAR_Event2_s( self );
      Escher_SendSelfEvent( (OoaEvent_t *)event6 );
    }
  }
  /* ELSE */
  else
  {
    /* SELECT ANY probe FROM INSTANCES OF SP
       WHERE (SELECTED.current_position == 'down') */
    v8 = (A_SP_s *)0;
    { /* Begin selection scope */
      A_SP_s * w7;
      Escher_Iterator_s iter9_SP;
      Escher_IteratorReset( &iter9_SP, pG_A_SP_extent );
      while ( (w7 = (A_SP_s *)Escher_IteratorNext( &iter9_SP )) != 0 )
      {
        if ( (w7->m_current_position == A_position_down_e) )
        {
          v8 = w7;
          break;
        }
      }
    } /* End selection scope */

    /* IF (NOT_EMPTY probe) */
    if ( (((v8 != 0) ? true : false)) )
    {
      /* GENERATE CAR2:'there'() TO SELF */
      {
        A_CAR_Event2_s * event10 = New_A_CAR_Event2_s( self );
        Escher_SendSelfEvent( (OoaEvent_t *)event10 );
      }
    }
    /* ELSE */
    else
    {
      /* BRIDGE CARPIO::carousel_spin(car_id:SELF.carousel_ID, destination:delta) */
      CARPIO_carousel_spin( self->m_carousel_ID, v5 );
    }
    /* END IF */
  }
  /* END IF */

}

